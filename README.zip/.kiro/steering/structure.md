# Project Structure

## Root Directory Layout
```
strands-agents-workshop/
├── main.py                    # Interactive application entry point
├── orchestrator_agent.py      # Main orchestrator implementation
├── sub_agents.py              # Four specialized sub-agents
├── mcp_tools.py               # MCP tool implementations
├── model_config.py            # Bedrock model configuration
├── workshop_test.py           # Integration test suite
├── run.sh                     # Automated setup and execution script
├── requirements.txt           # Python dependencies
├── README.md                  # Project documentation
└── templates/                 # Reference implementations
    ├── lab2-mcp_tools.py
    ├── lab3-sub_agents.py
    ├── lab4-orchestrator_agent.py
    └── lab5-main.py
```

## Core Components

### Agent Architecture
- **orchestrator_agent.py**: Central coordinator using "Agents as Tools" pattern
- **sub_agents.py**: Contains 4 specialized agents:
  - `planning_agent`: Execution plan creation
  - `search_agent`: Wikipedia + DuckDuckGo search
  - `weather_agent`: US weather information
  - `conversation_agent`: General conversation handling

### Tool Layer
- **mcp_tools.py**: MCP (Model Context Protocol) tools:
  - `wikipedia_search`: Wikipedia API integration
  - `duckduckgo_search`: DuckDuckGo API integration
  - `get_position`: Geocoding via OpenStreetMap
  - `http_request`: Generic HTTP requests (from strands_tools)

### Configuration
- **model_config.py**: Centralized Bedrock model configuration
- **requirements.txt**: Minimal dependency specification
- **.env**: Environment variables (AWS credentials, model settings)

## Code Organization Patterns

### Agent Definition Pattern
```python
@tool
def agent_name(input: str) -> str:
    """Agent description"""
    agent = Agent(
        model=get_configured_model(),
        system_prompt=AGENT_PROMPT,
        tools=[tool1, tool2]
    )
    return str(agent(input))
```

### Tool Definition Pattern
```python
@tool
def tool_name(param: str) -> Dict[str, Any]:
    """Tool description"""
    try:
        # Implementation
        return {"success": True, "data": result}
    except Exception as e:
        return {"success": False, "error": str(e)}
```

## File Naming Conventions
- Snake_case for Python files
- Descriptive names indicating component type
- Template files prefixed with lab number
- Test files suffixed with `_test`

## Import Structure
- Model configuration imported from `model_config`
- Tools imported from `mcp_tools` 
- Sub-agents imported from `sub_agents`
- External dependencies imported at module level