# Technology Stack

## Core Framework
- **Strands Agents**: Primary agent framework for building multi-agent systems
- **Strands Agents Tools**: Additional tooling and utilities
- **Amazon Bedrock**: LLM provider (Claude models)

## Dependencies
- **httpx**: Async HTTP client for API requests
- **wikipedia**: Wikipedia API integration
- **pydantic**: Data validation and serialization
- **python-dotenv**: Environment variable management

## Model Configuration
- **Default Model**: `anthropic.claude-3-haiku-20240307-v1:0`
- **Region**: `ap-northeast-2` (Seoul) for stability
- **Temperature**: 0.7 for balanced creativity/consistency
- **Max Tokens**: 4096
- **Streaming**: Disabled for workshop simplicity

## External APIs
- **Wikipedia API**: Information search and retrieval
- **DuckDuckGo API**: Web search functionality
- **OpenStreetMap Nominatim**: Geocoding services
- **National Weather Service**: US weather data

## Common Commands

### Environment Setup
```bash
# Quick start (automated)
./run.sh

# Manual setup
python3 -m venv venv
source venv/bin/activate  # Linux/Mac
pip install -r requirements.txt
```

### Testing
```bash
# Individual component tests
python3 mcp_tools.py
python3 sub_agents.py
python3 orchestrator_agent.py

# Integrated system test
python3 workshop_test.py

# Main application
python3 main.py
```

### Environment Variables
Required in `.env` file:
- `AWS_REGION`: AWS region (default: ap-northeast-2)
- `AWS_ACCESS_KEY_ID`: AWS credentials
- `AWS_SECRET_ACCESS_KEY`: AWS credentials
- `MODEL_ID`: Bedrock model ID (optional)