# Strands Agents Workshop Project Context

## Project Overview
This is a multi-agent system workshop implementing the "Agents as Tools" pattern using Strands Agents and Amazon Bedrock.

## Architecture
- **Orchestrator Agent**: Main coordinator that analyzes requests and delegates to sub-agents
- **Sub-Agents**: Planning, Search, Weather, Conversation agents
- **MCP Tools**: Wikipedia search, DuckDuckGo search, geolocation, HTTP requests
- **Processing Flow**: User Input → Orchestrator → Planning → Sub-agent Execution → Response

## Key Files
- `orchestrator_agent.py`: Main orchestrator implementation
- `sub_agents.py`: Four specialized sub-agents
- `mcp_tools.py`: MCP tool implementations
- `main.py`: Interactive application
- `model_config.py`: Bedrock model configuration
- `templates/`: Reference implementations for each lab

## Technology Stack
- Strands Agents framework
- Amazon Bedrock (Claude models)
- External APIs: Wikipedia, DuckDuckGo, Weather Service
- Python libraries: httpx, wikipedia, pydantic

## Workshop Labs
1. Environment setup
2. MCP Tools implementation
3. Sub-agents implementation  
4. Orchestrator implementation
5. Main application integration

## Current Status
All components are implemented and functional. The system demonstrates intelligent orchestration where the orchestrator automatically selects appropriate sub-agents based on user requests.