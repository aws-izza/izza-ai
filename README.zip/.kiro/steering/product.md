# Product Overview

## Strands Agents Workshop - Multi-Agent System

A workshop implementation demonstrating the "Agents as Tools" pattern using Strands Agents framework and Amazon Bedrock. The system features an orchestrator agent that intelligently delegates tasks to specialized sub-agents based on user requests.

## Core Functionality

- **Intelligent Orchestration**: Automatically analyzes user requests and selects appropriate sub-agents
- **Multi-Modal Search**: Wikipedia and DuckDuckGo integration for comprehensive information retrieval  
- **Weather Services**: US-based weather information via National Weather Service API
- **Natural Conversation**: General conversation handling with emotional intelligence
- **Execution Planning**: Strategic planning agent for complex multi-step requests

## Architecture Pattern

The system implements a hierarchical agent structure where:
1. User input → Orchestrator Agent
2. Orchestrator → Planning Agent (creates execution plan)
3. Orchestrator → Specialized Sub-Agents (executes plan)
4. Final response synthesis and delivery

## Target Use Cases

- Educational workshops on multi-agent systems
- Demonstration of AI orchestration patterns
- Reference implementation for production agent systems
- Learning tool for Strands Agents framework